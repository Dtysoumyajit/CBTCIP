<h1>Event Brite Project</h1>
<a style="font-size:30px;font-style:bold;font-weight: 900;" href="https://github.com/arman-mondal/eventbrite.git" >Backend</a>
<img src="https://github.com/arman-mondal/eventbrite/raw/main/img/1.png"/>
<img src="https://github.com/arman-mondal/eventbrite/raw/main/img/2.png"/>
<img src="https://raw.githubusercontent.com/arman-mondal/eventbrite/main/img/3.png"/>
