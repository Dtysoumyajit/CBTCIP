<h1>Event Brite Project</h1>
<center><a href="https://google.com" >Frontend</a></center>
<img src="/img/1.png"/>
<img src="/img/2.png"/>
<img src="/img//3.png"/>
